package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText num1 = (EditText) findViewById(R.id.Quizes);
        final EditText num2 = (EditText) findViewById(R.id.Homework);
        final EditText num3 = (EditText) findViewById(R.id.MidTerms);
        final EditText num4 = (EditText) findViewById(R.id.Final);
        final Button Calculate = (Button) findViewById(R.id.Calculatebtn);
        final Button Reset = (Button) findViewById(R.id.Resetbtn);
        final TextView Result = (TextView) findViewById(R.id.Result);

        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 int number1 = Integer.parseInt(num1.getText().toString());
                 int number2 = Integer.parseInt(num2.getText().toString());
                 int number3 = Integer.parseInt(num3.getText().toString());
                 int number4 = Integer.parseInt(num4.getText().toString());
                 int FinalResult = number1 + number2 + number3 + number4;
                Result.setText(FinalResult +"");


            }
        });
        Reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1.setText(null);
                num2.setText(null);
                num3.setText(null);
                num4.setText(null);
                Result.setText("Result");
            }
        });
    }
}